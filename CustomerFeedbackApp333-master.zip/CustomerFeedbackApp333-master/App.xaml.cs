using CustomerFeedbackApp.ViewModels;
namespace CustomerFeedbackApp;
public partial class App : Application
{
    private readonly FeedbackViewModel feedbackVm;
    public App(AppShell shell, FeedbackViewModel feedbackVm)
    {
        InitializeComponent();
        this.feedbackVm = feedbackVm;
        MainPage = shell;
        System.Diagnostics.Debug.WriteLine("[App] Constructor");
    }
    protected override void OnStart() { base.OnStart(); System.Diagnostics.Debug.WriteLine("[App] OnStart"); }
    protected override void OnSleep() { feedbackVm.SaveDraft(); System.Diagnostics.Debug.WriteLine("[App] OnSleep"); base.OnSleep(); }
    protected override void OnResume() { base.OnResume(); feedbackVm.RestoreDraft(); System.Diagnostics.Debug.WriteLine("[App] OnResume"); }
    protected override Window CreateWindow(IActivationState? activationState)
    {
        System.Diagnostics.Debug.WriteLine("[App] CreateWindow");
        return base.CreateWindow(activationState);
    }
}
