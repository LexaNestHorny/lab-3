using CustomerFeedbackApp.Models;
using SQLite;
namespace CustomerFeedbackApp.Services;
public sealed class DatabaseService
{
    private readonly SQLiteAsyncConnection connection;
    private readonly Task initialization;
    public DatabaseService()
    {
        var path = Path.Combine(FileSystem.AppDataDirectory, "feedbacks.db3");
        connection = new SQLiteAsyncConnection(path);
        initialization = connection.CreateTableAsync<Feedback>();
    }
    private async Task ReadyAsync() => await initialization;
    public async Task<List<Feedback>> GetAllAsync()
    {
        await ReadyAsync();
        return await connection.Table<Feedback>().OrderByDescending(x => x.Id).ToListAsync();
    }
    public async Task<Feedback?> GetByIdAsync(int id)
    {
        await ReadyAsync();
        return await connection.Table<Feedback>().Where(x => x.Id == id).FirstOrDefaultAsync();
    }
    public async Task<int> InsertAsync(Feedback item) { await ReadyAsync(); return await connection.InsertAsync(item); }
    public async Task<int> UpdateAsync(Feedback item) { await ReadyAsync(); return await connection.UpdateAsync(item); }
    public async Task<int> DeleteAsync(Feedback item) { await ReadyAsync(); return await connection.DeleteAsync(item); }
}
