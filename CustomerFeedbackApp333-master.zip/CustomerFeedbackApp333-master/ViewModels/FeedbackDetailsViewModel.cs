using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CustomerFeedbackApp.Helpers;
using CustomerFeedbackApp.Models;
using CustomerFeedbackApp.Services;
namespace CustomerFeedbackApp.ViewModels;
public partial class FeedbackDetailsViewModel : ObservableObject, IQueryAttributable, ILifecycleAware
{
    private readonly DatabaseService database;
    private Feedback? current;
    [ObservableProperty] private string customerName = string.Empty;
    [ObservableProperty] private string comment = string.Empty;
    [ObservableProperty] private int selectedRating = 5;
    [ObservableProperty] private string createdText = string.Empty;
    [ObservableProperty] private string statusMessage = string.Empty;
    [ObservableProperty] private bool isBusy;
    public List<int> Ratings { get; } = new() { 1, 2, 3, 4, 5 };
    public FeedbackDetailsViewModel(DatabaseService database) => this.database = database;
    public void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        if (!query.TryGetValue("id", out var raw) || !int.TryParse(raw?.ToString(), out var id))
        { StatusMessage = "Невірний ID відгуку"; return; }
        _ = LoadAsync(id);
    }
    private async Task LoadAsync(int id)
    {
        IsBusy = true;
        try
        {
            current = await database.GetByIdAsync(id);
            if (current is null) { StatusMessage = "Відгук не знайдено"; return; }
            CustomerName = current.CustomerName;
            Comment = current.Comment;
            SelectedRating = current.Rating;
            CreatedText = $"Дата: {current.CreatedAt:dd.MM.yyyy HH:mm}";
            StatusMessage = "Можна змінити або видалити відгук";
        }
        catch (Exception ex) { StatusMessage = $"Помилка: {ex.Message}"; }
        finally { IsBusy = false; }
    }
    [RelayCommand]
    private async Task SaveAsync()
    {
        if (current is null || IsBusy) return;
        if (string.IsNullOrWhiteSpace(CustomerName) || string.IsNullOrWhiteSpace(Comment) || SelectedRating is < 1 or > 5)
        { StatusMessage = "Заповніть усі поля коректно"; return; }
        IsBusy = true;
        try
        {
            current.CustomerName = CustomerName.Trim(); current.Comment = Comment.Trim(); current.Rating = SelectedRating;
            await database.UpdateAsync(current);
            await Shell.Current.GoToAsync("..");
        }
        catch (Exception ex) { StatusMessage = $"Помилка оновлення: {ex.Message}"; }
        finally { IsBusy = false; }
    }
    [RelayCommand]
    private async Task DeleteAsync()
    {
        if (current is null || IsBusy) return;
        IsBusy = true;
        try { await database.DeleteAsync(current); await Shell.Current.GoToAsync(".."); }
        catch (Exception ex) { StatusMessage = $"Помилка видалення: {ex.Message}"; }
        finally { IsBusy = false; }
    }
    [RelayCommand] private async Task BackAsync() => await Shell.Current.GoToAsync("..");
    public void OnAppearing() => System.Diagnostics.Debug.WriteLine("[VM] Details OnAppearing");
    public void OnDisappearing() => System.Diagnostics.Debug.WriteLine("[VM] Details OnDisappearing");
}
