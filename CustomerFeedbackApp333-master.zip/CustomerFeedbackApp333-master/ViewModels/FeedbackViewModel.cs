using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CustomerFeedbackApp.Helpers;
using CustomerFeedbackApp.Models;
using CustomerFeedbackApp.Services;
using Microsoft.Maui.Storage;
namespace CustomerFeedbackApp.ViewModels;
public partial class FeedbackViewModel : ObservableObject, ILifecycleAware
{
    private const string NameKey = "draft_customer_name";
    private const string CommentKey = "draft_comment";
    private const string RatingKey = "draft_rating";
    private readonly DatabaseService database;
    [ObservableProperty] private string customerName = string.Empty;
    [ObservableProperty] private string comment = string.Empty;
    [ObservableProperty] private int selectedRating = 5;
    [ObservableProperty] private string statusMessage = "Заповніть форму та залиште відгук";
    [ObservableProperty] private bool isBusy;
    public ObservableCollection<Feedback> Feedbacks { get; } = new();
    public List<int> Ratings { get; } = new() { 1, 2, 3, 4, 5 };
    public FeedbackViewModel(DatabaseService database)
    {
        this.database = database;
        RestoreDraft();
    }
    public void RestoreDraft()
    {
        CustomerName = Preferences.Default.Get(NameKey, string.Empty);
        Comment = Preferences.Default.Get(CommentKey, string.Empty);
        SelectedRating = Preferences.Default.Get(RatingKey, 5);
    }
    public void SaveDraft()
    {
        Preferences.Default.Set(NameKey, CustomerName);
        Preferences.Default.Set(CommentKey, Comment);
        Preferences.Default.Set(RatingKey, SelectedRating);
    }
    public void OnAppearing() { _ = LoadFeedbacksAsync(); System.Diagnostics.Debug.WriteLine("[VM] Feedback OnAppearing"); }
    public void OnDisappearing() { SaveDraft(); System.Diagnostics.Debug.WriteLine("[VM] Feedback OnDisappearing"); }
    [RelayCommand]
    private async Task LoadFeedbacksAsync()
    {
        if (IsBusy) return;
        IsBusy = true;
        try
        {
            var items = await database.GetAllAsync();
            Feedbacks.Clear();
            foreach (var item in items) Feedbacks.Add(item);
        }
        catch (Exception ex) { StatusMessage = $"Помилка завантаження: {ex.Message}"; }
        finally { IsBusy = false; }
    }
    [RelayCommand]
    private async Task AddFeedbackAsync()
    {
        if (IsBusy) return;
        if (string.IsNullOrWhiteSpace(CustomerName) || string.IsNullOrWhiteSpace(Comment))
        { StatusMessage = "Введіть ім'я клієнта та текст відгуку."; return; }
        if (SelectedRating is < 1 or > 5) { StatusMessage = "Оцінка має бути від 1 до 5."; return; }
        IsBusy = true;
        try
        {
            await database.InsertAsync(new Feedback { CustomerName = CustomerName.Trim(), Rating = SelectedRating, Comment = Comment.Trim() });
            CustomerName = string.Empty; Comment = string.Empty; SelectedRating = 5;
            SaveDraft();
            var items = await database.GetAllAsync();
            Feedbacks.Clear();
            foreach (var item in items) Feedbacks.Add(item);
            StatusMessage = $"Відгук збережено в SQLite! Усього: {Feedbacks.Count}";
        }
        catch (Exception ex) { StatusMessage = $"Помилка збереження: {ex.Message}"; }
        finally { IsBusy = false; }
    }
    [RelayCommand]
    private async Task OpenFeedbackAsync(Feedback? feedback)
    {
        if (feedback is null) return;
        SaveDraft();
        await Shell.Current.GoToAsync($"details?id={feedback.Id}");
    }
}
