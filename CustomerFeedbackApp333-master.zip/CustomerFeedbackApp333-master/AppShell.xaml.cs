using CustomerFeedbackApp.Views;
namespace CustomerFeedbackApp;
public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute("details", typeof(FeedbackDetailsPage));
    }
}
