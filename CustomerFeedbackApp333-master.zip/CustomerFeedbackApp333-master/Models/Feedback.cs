using SQLite;
namespace CustomerFeedbackApp.Models;
[Table("Feedbacks")]
public class Feedback
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [NotNull, MaxLength(120)] public string CustomerName { get; set; } = string.Empty;
    public int Rating { get; set; } = 5;
    [NotNull] public string Comment { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
