using CustomerFeedbackApp.Services;
using CustomerFeedbackApp.ViewModels;
using CustomerFeedbackApp.Views;
namespace CustomerFeedbackApp;
public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();
        builder.Services.AddSingleton<DatabaseService>();
        builder.Services.AddSingleton<FeedbackViewModel>();
        builder.Services.AddSingleton<MainPage>();
        builder.Services.AddSingleton<AppShell>();
        builder.Services.AddTransient<FeedbackDetailsViewModel>();
        builder.Services.AddTransient<FeedbackDetailsPage>();
        return builder.Build();
    }
}
