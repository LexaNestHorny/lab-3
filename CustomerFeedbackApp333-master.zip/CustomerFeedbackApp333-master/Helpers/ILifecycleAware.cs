namespace CustomerFeedbackApp.Helpers;
public interface ILifecycleAware
{
    void OnAppearing();
    void OnDisappearing();
}
