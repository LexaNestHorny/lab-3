using CustomerFeedbackApp.Helpers;
using CustomerFeedbackApp.ViewModels;
namespace CustomerFeedbackApp.Views;
public partial class FeedbackDetailsPage : ContentPage
{
    public FeedbackDetailsPage(FeedbackDetailsViewModel vm) { InitializeComponent(); BindingContext = vm; }
    protected override void OnAppearing() { base.OnAppearing(); (BindingContext as ILifecycleAware)?.OnAppearing(); }
    protected override void OnDisappearing() { (BindingContext as ILifecycleAware)?.OnDisappearing(); base.OnDisappearing(); }
}
